
# tenhle zakomentovany text je tady pro to aby az se to bude delat znovu tak aby AI vedela aspon neco jak se to delalo :D 

library(dplyr)
library(readr)
library(sf)
library(stringr)

# Existing hut-reservation huts
hr <- read_csv("data/huts.csv", show_col_types = FALSE) %>%
  filter(!is.na(lat), !is.na(lon))

# Alpenverein Hut Finder huts
av <- read_csv("alpenverein_huts.csv", show_col_types = FALSE) %>%
  filter(!is.na(lat), !is.na(lon)) %>%
  mutate(
    huette_nr = str_pad(as.character(huette_nr), width = 4, pad = "0"),
    source_url = if_else(
      is.na(source_url) | source_url == "",
      paste0("https://www.alpenverein.at/huetten-en/index.php?huette_nr=", huette_nr),
      source_url
    ),
    layer_type = "alpenverein_only"
  )

# Convert to spatial objects
hr_sf <- st_as_sf(hr, coords = c("lon", "lat"), crs = 4326, remove = FALSE)
av_sf <- st_as_sf(av, coords = c("lon", "lat"), crs = 4326, remove = FALSE)

# Use metric projection for distance filtering
hr_m <- st_transform(hr_sf, 3857)
av_m <- st_transform(av_sf, 3857)

# Find nearest hut-reservation hut for every Alpenverein hut
nearest_hr <- st_nearest_feature(av_m, hr_m)

distance_to_hr_m <- as.numeric(
  st_distance(av_m, hr_m[nearest_hr, ], by_element = TRUE)
)

av_extra <- av_sf %>%
  mutate(distance_to_hr_m = distance_to_hr_m) %>%
  filter(distance_to_hr_m > 200) %>%   # adjust if needed: 150–300 m
  select(
    huette_nr,
    hut_source_name,
    lat,
    lon,
    source_url,
    layer_type,
    distance_to_hr_m
  )

message("Alpenverein huts total: ", nrow(av))
message("Alpenverein-only huts after deduplication: ", nrow(av_extra))

st_write(
  av_extra,
  "data/alpenverein_extra_huts.geojson",
  delete_dsn = TRUE
)


# Pokud knihovny ještě nemáš, nainstaluj je pomocí:
# install.packages(c("sf", "dplyr"))

library(sf)
library(dplyr)

# 1. Načtení tvých dat (nahraď svými reálnými názvy proměnných nebo souborů)
 df1 <- read.csv("av_hut_coordinates.csv") %>% filter(is.na(lat) ==FALSE) %>%  filter(is.na(lon) ==FALSE)
 df2 <- read_excel("huts_location_from_google_spreadsheet.xlsx")

# 2. Převedení obou tabulek na prostorové objekty (sf)
# Parametr 'coords' vyžaduje pořadí (X, Y), takže nejprve 'lon', pak 'lat'
# remove = FALSE zajistí, že ti původní sloupce lon a lat v tabulce zůstanou
sf1 <- st_as_sf(df1 , coords = c("lon", "lat"), crs = 4326, remove = FALSE)
sf2 <- st_as_sf(df2, coords = c("lon", "lat"), crs = 4326, remove = FALSE)

# 3. Prostorové spojení (Spatial Join)
# Přiřadí data z sf2 k sf1, pokud je vzdálenost menší nebo rovna 100 metrům
vysledek_sf <- st_join(sf1, sf2, join = st_is_within_distance, dist = 200)

# 4. Převod zpět na klasický Data Frame (odstranění prostorových metadat)
alpenverein_huts_not_in_reservation_system <- vysledek_sf %>% st_drop_geometry()

alpenverein_huts_not_in_reservation_system <- alpenverein_huts_not_in_reservation_system %>%
  mutate(hut_source_name = str_remove(hut_source_name, " Akademie Shop Membership hut finder.*")) %>% 
  filter(is.na(hut_name)==TRUE) %>% 
  transmute(huette_nr,hut_source_name,lat = lat.x, lon = lon.x, source_url)
  


st_write(
  alpenverein_huts_not_in_reservation_system,
  "alpenverein_extra_huts.geojson",
  delete_dsn = TRUE
)


